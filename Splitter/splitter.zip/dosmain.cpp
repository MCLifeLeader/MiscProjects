
int main( int argc, char *argv[] );

void note( char *String );
void windisplay( char *String );
int Proc_Arguments( char *String );

int main( int argc, char *argv[] )
{
	return( 0 );
}

int Proc_Arguments( char *String )
{
	return 0;
}
