/****************************************************************************
Program:    SPLITTER.EXE
Author:     Mike Carey
Date:			03/26/98
Last Mod:	06/12/98
Compiler:   Borland C++ 5.02
Email:		mbcarey@owt.com

****************************************************************************
Comments:	This program is designed to Split up large files into smaller ones
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "splitter.h"

#if OS2GUI == 1

#endif


