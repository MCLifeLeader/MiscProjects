//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by splitter.rc
//
#define VERSIONINFO_1                   1
#define SPLITAPP                        1
#define IDD_FORCEFXINFO                 1
#define SPLIT_LOGO                      1
#define SPLITAPM                        1
#define SPLITAPMSML                     2
#define IDD_FILESPLTSIZE                2
#define COOL_ICO                        3
#define IDD_ABOUTWINSPLIT               3
#define SPLITILOGO                      4
#define IDC_STATICTEXT5                 101
#define IDC_LISTBOX1                    101
#define IDC_STATICTEXT4                 102
#define IDC_STATICBITMAP1               103
#define IDC_STATICFRAME1                103
#define IDC_STATICTEXT1                 104
#define IDC_STATICTEXT2                 105
#define IDC_STATICTEXT3                 106
#define IDC_STATICTEXT6                 107
#define IDC_STATICTEXT7                 108
#define IDC_STATICTEXT8                 109
#define IDC_STATICFRAME2                109
#define IDM_NEW                         200
#define IDM_OPEN                        202
#define IDM_SPLIT                       204
#define IDM_COMBINE                     206
#define IDM_FORCE                       208
#define IDM_EXIT                        210
#define IDM_ABOUT                       212
#define IDM_SETSPLIT                    213
#define IDPICCONTRL                     1000
#define IDC_OUTFILEN                    1001
#define IDC_IN_FILEN                    1002
#define IDC_SPLITSIZE                   1003
#define IDC_SPLITCOUNT                  1004
#define IDC_GETFILEN                    1005
#define IDC_GETFILEN2                   1006
#define CM_SPLITSIZEITEM2               18873
#define CM_SPLITSIZEITEM1               18873
#define CM_ITEM3                        18873
#define CM_ITEM2                        18873
#define CM_ITEM1                        18873
#define CM_ITEM4                        18873

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
